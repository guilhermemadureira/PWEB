function ptp(a){

    pc = (Math.floor(Math.random() * 3) + 1);
    if(pc == 3 && a == 3){
        alert("PC escolheu Tesoura");
        return(alert("Empate."));
    }else if(pc == 3 && a == 2){
        alert("PC escolheu Tesoura");
        return(alert("Tesoura corta papel. PC venceu"));
    }else if(pc == 3 && a == 1){
        alert("PC escolheu Tesoura");
        return(alert("Pedra quebra tesoura. Jogador venceu"));
    }
    if((pc == 2) && a == 2){
        alert("PC escolheu papel")
        return(alert("Empate."));
    }else if(pc == 2 && a == 1){
        alert("PC escolheu papel")
        return(alert("papel cobre a pedra.  PC venceu"));
    }else if(pc == 2 && a == 3){
        alert("PC escolheu papel");
        return(alert("Tesoura corta papel. Jogador venceu"));
    }
    if(pc == 1 && a == 1){
        alert("PC escolheu pedra")
        return(alert("Empate."));
    }else if(pc == 1 && a == 2){
        alert("PC escolheu pedra")
        return(alert("papel cobre a pedra. Jogador venceu"));
    }else if(pc == 1 && a == 3){
        alert("PC escolheu pedra")
        return(alert("Pedra quebra tesoura. PC venceu"));
    }
}

let aux = 0;
alert("Vamos jogar um jogo de pedra papel,papel ou tesoura");
aux = prompt("1 => pedra, 2=> Papel, 3=> Tesoura");
ptp(aux);