function mensagem(){
    alert("Abra a janela");
    document.getElementById('Janela').src= "img/janelafechada.png";
}
function abrir(){
    document.getElementById('Janela').src= "img/janelaaberta.png";
}
function fechar(){
    document.getElementById('Janela').src= "img/janelafechada.png";

}
function quebrar(){
    document.getElementById('Janela').src= "img/janelaquebra.png";
}onmouseleave